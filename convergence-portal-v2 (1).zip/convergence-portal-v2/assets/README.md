# assets/

Drop brand image files here. The app references them by relative path and
falls back gracefully if they are missing, so the repo runs fine without them —
but it looks more polished once they're in place.

## Needed

- **`logo-horizontal.png`** — the horizontal Convergence wordmark shown in the
  expanded sidebar. Rendered at 24px height, max width ~172px. A transparent
  PNG works best (the app applies a white filter so a dark/black logo on
  transparency will display correctly on the dark sidebar).

If `logo-horizontal.png` is absent, the sidebar shows a text fallback
("C" mark + "CONVERGENCE"). No error, no broken-image icon.

## How to add it

In GitHub: **Add file → Upload files**, drag the PNG in, and make sure the
path is `assets/logo-horizontal.png` before committing.
